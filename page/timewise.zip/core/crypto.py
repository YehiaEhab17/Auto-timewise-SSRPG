import hashlib
import hmac


def pbkdf2_hmac_sha1(password, salt, iterations, dk_len):
    """Pure-Python PBKDF2-HMAC-SHA1.

    Pyodide's build has no OpenSSL, so `hashlib.pbkdf2_hmac` is unavailable.
    This reimplements it using `hmac` + `hashlib.sha1`, both of which work in
    Pyodide. Output is byte-identical to `hashlib.pbkdf2_hmac`.
    """
    hlen = 20  # SHA-1 digest size in bytes
    blocks = (dk_len + hlen - 1) // hlen  # number of blocks, l = ceil(dk_len/hlen)

    derived = b""
    for index in range(1, blocks + 1):
        # U1 = HMAC(password, salt || INT_32_BE(index))
        u = hmac.new(password, salt + index.to_bytes(4, "big"), hashlib.sha1).digest()

        # T_i = U1 XOR U2 XOR ... XOR U_iterations
        result = u
        for _ in range(1, iterations):
            u = hmac.new(password, u, hashlib.sha1).digest()
            result = bytes(a ^ b for a, b in zip(result, u))

        derived += result

    return derived[:dk_len]
